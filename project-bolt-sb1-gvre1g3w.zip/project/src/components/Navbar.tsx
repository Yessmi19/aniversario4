import React from 'react';
import { Heart, Home, Plus, Clock, MessageCircle, Calendar } from 'lucide-react';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, setCurrentPage }) => {
  const navItems = [
    { id: 'home', label: 'Inicio', icon: Home },
    { id: 'add-memory', label: 'Agregar Memoria', icon: Plus },
    { id: 'timeline', label: 'Nuestra Historia', icon: Clock },
    { id: 'messages', label: 'Mensajes', icon: MessageCircle },
    { id: 'anniversary', label: '4 Meses ♥', icon: Calendar },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 bg-white/90 backdrop-blur-md shadow-lg z-50 border-b border-purple-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <Heart className="h-8 w-8 text-purple-500 fill-current animate-pulse" />
            <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-blue-500 bg-clip-text text-transparent">
              Corazones Unidos ♡
            </span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setCurrentPage(id)}
                className={`flex items-center space-x-2 px-3 py-2 rounded-full transition-all duration-300 ${
                  currentPage === id
                    ? 'bg-purple-100 text-purple-600 shadow-md'
                    : 'text-gray-600 hover:text-purple-500 hover:bg-purple-50'
                }`}
              >
                <Icon className="h-4 w-4" />
                <span className="font-medium">{label}</span>
              </button>
            ))}
          </div>

          {/* Mobile menu */}
          <div className="md:hidden">
            <div className="flex space-x-1">
              {navItems.map(({ id, icon: Icon }) => (
                <button
                  key={id}
                  onClick={() => setCurrentPage(id)}
                  className={`p-2 rounded-full transition-all duration-300 ${
                    currentPage === id
                      ? 'bg-purple-100 text-purple-600'
                      : 'text-gray-600 hover:text-purple-500'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;