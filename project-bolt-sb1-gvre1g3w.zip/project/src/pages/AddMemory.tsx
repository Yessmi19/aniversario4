import React, { useState } from 'react';
import { Camera, Heart, Upload, Save, Sparkles } from 'lucide-react';

const AddMemory: React.FC = () => {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    imageUrl: '',
    date: new Date().toISOString().split('T')[0]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate upload delay
    setTimeout(() => {
      const newMemory = {
        id: Date.now().toString(),
        image: formData.imageUrl,
        title: formData.title,
        description: formData.description,
        date: formData.date
      };

      const existingMemories = JSON.parse(localStorage.getItem('memories') || '[]');
      const updatedMemories = [...existingMemories, newMemory];
      localStorage.setItem('memories', JSON.stringify(updatedMemories));

      setShowSuccess(true);
      setFormData({
        title: '',
        description: '',
        imageUrl: '',
        date: new Date().toISOString().split('T')[0]
      });
      setIsSubmitting(false);

      setTimeout(() => setShowSuccess(false), 3000);
    }, 1500);
  };

  const handleImageUrl = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, imageUrl: e.target.value });
  };

  const suggestedImages = [
    'https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg',
    'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg',
    'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg',
    'https://images.pexels.com/photos/1002638/pexels-photo-1002638.jpeg',
    'https://images.pexels.com/photos/1024967/pexels-photo-1024967.jpeg',
    'https://images.pexels.com/photos/1024970/pexels-photo-1024970.jpeg'
  ];

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center items-center mb-4">
            <div className="relative">
              <Camera className="h-12 w-12 text-purple-500" />
              <Sparkles className="h-6 w-6 text-yellow-400 absolute -top-2 -right-2 animate-pulse" />
            </div>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-500 to-slate-600 bg-clip-text text-transparent mb-4">
            Crear Nueva Memoria
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Inmortaliza otro momento especial de nuestra historia de amor
          </p>
        </div>

        {/* Success Message */}
        {showSuccess && (
          <div className="mb-8 p-4 bg-green-50 border border-green-200 rounded-2xl">
            <div className="flex items-center">
              <Heart className="h-5 w-5 text-green-500 fill-current mr-3" />
              <span className="text-green-800 font-medium">¡Memoria guardada con amor! ♥</span>
            </div>
          </div>
        )}

        <div className="bg-white rounded-3xl shadow-xl overflow-hidden">
          <div className="p-8">
            <form onSubmit={handleSubmit} className="space-y-8">
              {/* Title */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Título de la Memoria *
                </label>
                <input
                  type="text"
                  required
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="Ej: Nuestra primera aventura juntos..."
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-300 focus:border-purple-400 transition-colors duration-200"
                />
              </div>

              {/* Description */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Descripción *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Cuéntanos sobre este momento especial... ¿Qué lo hace tan especial? ¿Cómo te sentiste?"
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-300 focus:border-purple-400 transition-colors duration-200 resize-none"
                />
              </div>

              {/* Date */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  Fecha *
                </label>
                <input
                  type="date"
                  required
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-300 focus:border-purple-400 transition-colors duration-200"
                />
              </div>

              {/* Image URL */}
              <div>
                <label className="block text-sm font-bold text-gray-700 mb-2">
                  URL de la Imagen *
                </label>
                <div className="relative">
                  <input
                    type="url"
                    required
                    value={formData.imageUrl}
                    onChange={handleImageUrl}
                    placeholder="https://ejemplo.com/mi-imagen.jpg"
                    className="w-full px-4 py-3 pr-12 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-300 focus:border-purple-400 transition-colors duration-200"
                  />
                  <Upload className="absolute right-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
                </div>
                
                {/* Image Suggestions */}
                <div className="mt-4">
                  <p className="text-sm text-gray-600 mb-3">O elige una de estas imágenes sugeridas:</p>
                  <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                    {suggestedImages.map((url, index) => (
                      <button
                        key={index}
                        type="button"
                        onClick={() => setFormData({ ...formData, imageUrl: url })}
                        className={`aspect-square rounded-lg overflow-hidden border-2 transition-all duration-200 ${
                          formData.imageUrl === url 
                            ? 'border-purple-400 ring-2 ring-purple-200' 
                            : 'border-gray-200 hover:border-purple-300'
                        }`}
                      >
                        <img
                          src={url}
                          alt={`Sugerencia ${index + 1}`}
                          className="w-full h-full object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Image Preview */}
              {formData.imageUrl && (
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">
                    Vista Previa
                  </label>
                  <div className="relative aspect-video rounded-xl overflow-hidden bg-gray-100">
                    <img
                      src={formData.imageUrl}
                      alt="Vista previa"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg';
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Submit Button */}
              <div className="flex justify-center">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`flex items-center space-x-2 px-8 py-4 rounded-full text-white font-bold text-lg transition-all duration-300 ${
                    isSubmitting
                      ? 'bg-gray-400 cursor-not-allowed'
                      : 'bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 shadow-lg hover:shadow-xl transform hover:-translate-y-1'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                      <span>Guardando con amor...</span>
                    </>
                  ) : (
                    <>
                      <Save className="h-5 w-5" />
                      <span>Guardar Memoria</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddMemory;