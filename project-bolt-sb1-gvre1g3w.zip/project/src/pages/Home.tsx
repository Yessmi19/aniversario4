import React, { useState, useEffect } from 'react';
import { Heart, Camera, Quote } from 'lucide-react';

interface Memory {
  id: string;
  image: string;
  title: string;
  description: string;
  date: string;
}

const Home: React.FC = () => {
  const [memories, setMemories] = useState<Memory[]>([]);

  useEffect(() => {
    const savedMemories = localStorage.getItem('memories');
    if (savedMemories) {
      setMemories(JSON.parse(savedMemories));
    } else {
      // Memorias de ejemplo con imágenes de Pexels
      const defaultMemories: Memory[] = [
        {
          id: '1',
          image: 'https://images.pexels.com/photos/1024960/pexels-photo-1024960.jpeg',
          title: 'Nuestra Primera Cita',
          description: 'El día que comenzó nuestra hermosa historia de amor. Cada momento contigo es mágico.',
          date: '2024-08-15'
        },
        {
          id: '2',
          image: 'https://images.pexels.com/photos/1024993/pexels-photo-1024993.jpeg',
          title: 'Primer Te Amo',
          description: 'Las palabras más hermosas que jamás escuché. Mi corazón supo que eras tú para siempre.',
          date: '2024-09-02'
        },
        {
          id: '3',
          image: 'https://images.pexels.com/photos/1592384/pexels-photo-1592384.jpeg',
          title: 'Nuestro Lugar Especial',
          description: 'Donde hicimos tantas promesas y creamos tantos recuerdos inolvidables juntos.',
          date: '2024-10-10'
        }
      ];
      setMemories(defaultMemories);
      localStorage.setItem('memories', JSON.stringify(defaultMemories));
    }
  }, []);

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center items-center mb-4">
            <Heart className="h-12 w-12 text-purple-500 fill-current animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-500 to-slate-700 bg-clip-text text-transparent mb-4">
            Nuestra Historia de Amor
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto leading-relaxed">
            Cada momento juntos es una página preciosa en el libro de nuestro amor.
            Aquí guardamos todos esos instantes mágicos que hacen que nuestro corazón lata más fuerte.
          </p>
        </div>

        {/* Memories Grid */}
        {memories.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {memories.map((memory, index) => (
              <div
                key={memory.id}
                className="group relative bg-white rounded-2xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 animate-fade-in"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="relative aspect-[4/3] overflow-hidden">
                  <img
                    src={memory.image}
                    alt={memory.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                  <div className="absolute top-4 right-4 bg-white/90 backdrop-blur-sm rounded-full p-2 opacity-0 group-hover:opacity-100 transition-all duration-300">
                    <Camera className="h-4 w-4 text-purple-500" />
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-xl font-bold text-gray-800">{memory.title}</h3>
                    <Quote className="h-5 w-5 text-purple-400" />
                  </div>
                  <p className="text-gray-600 leading-relaxed mb-4">{memory.description}</p>
                  <div className="flex items-center text-sm text-purple-500 font-medium">
                    <Heart className="h-4 w-4 mr-2 fill-current" />
                    {new Date(memory.date).toLocaleDateString('es-ES', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-16">
            <Camera className="h-24 w-24 text-purple-300 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-gray-700 mb-4">Aún no hay memorias</h3>
            <p className="text-gray-500 mb-8 max-w-md mx-auto">
              Comienza a crear vuestra galería de momentos especiales agregando la primera memoria
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;