import React, { useState } from 'react';
import { Heart, MessageCircle, Send, Star, Quote } from 'lucide-react';

const Messages: React.FC = () => {
  const [newMessage, setNewMessage] = useState('');
  const [messages, setMessages] = useState([
    {
      id: 1,
      text: 'Cada día a tu lado es un regalo. Gracias por llenar mi vida de color y amor.',
      date: '2024-12-10',
      hearts: 12
    },
    {
      id: 2,
      text: 'Eres la melodía más hermosa que ha llegado a mi corazón. Te amo infinitamente.',
      date: '2024-12-08',
      hearts: 15
    },
    {
      id: 3,
      text: 'En tus ojos encuentro mi hogar, en tus brazos mi paz, en tu corazón mi eternidad.',
      date: '2024-12-05',
      hearts: 18
    }
  ]);

  const loveQuotes = [
    "El amor verdadero no tiene final, porque cada día se renueva.",
    "Eres mi persona favorita en el mundo entero.",
    "Contigo aprendí que el amor es mucho más hermoso de lo que imaginaba.",
    "En cada latido de mi corazón susurro tu nombre.",
    "Eres mi sueño hecho realidad y mi realidad más hermosa."
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newMessage.trim()) {
      const message = {
        id: Date.now(),
        text: newMessage,
        date: new Date().toISOString().split('T')[0],
        hearts: 0
      };
      setMessages([message, ...messages]);
      setNewMessage('');
    }
  };

  const addHeart = (id: number) => {
    setMessages(messages.map(msg => 
      msg.id === id ? { ...msg, hearts: msg.hearts + 1 } : msg
    ));
  };

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center items-center mb-4">
            <MessageCircle className="h-12 w-12 text-purple-500" />
            <Heart className="h-6 w-6 text-blue-400 fill-current ml-2 animate-pulse" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-600 via-blue-500 to-slate-600 bg-clip-text text-transparent mb-4">
            Cartas de Amor
          </h1>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Un espacio sagrado para nuestros sentimientos más profundos y las palabras que nacen del corazón
          </p>
        </div>

        {/* Write new message */}
        <div className="bg-white rounded-3xl shadow-xl p-8 mb-12">
          <h2 className="text-2xl font-bold text-gray-800 mb-6 flex items-center">
            <Send className="h-6 w-6 text-purple-500 mr-3" />
            Escribir Nuevo Mensaje
          </h2>
          <form onSubmit={handleSubmit} className="space-y-6">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Escribe aquí tus sentimientos más profundos... cada palabra será guardada con amor ♥"
              rows={6}
              className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-purple-300 focus:border-purple-400 transition-colors duration-200 resize-none"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                disabled={!newMessage.trim()}
                className="flex items-center space-x-2 px-6 py-3 bg-gradient-to-r from-purple-500 to-blue-500 text-white font-bold rounded-full hover:from-purple-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 hover:-translate-y-1 shadow-lg"
              >
                <Send className="h-4 w-4" />
                <span>Enviar con Amor</span>
              </button>
            </div>
          </form>
        </div>

        {/* Love quotes inspiration */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 border border-purple-100">
            <h3 className="text-lg font-bold text-purple-700 mb-4 flex items-center">
              <Quote className="h-5 w-5 mr-2" />
              Frases de Inspiración
            </h3>
            <div className="space-y-3">
              {loveQuotes.slice(0, 3).map((quote, index) => (
                <p key={index} className="text-purple-600 italic text-sm leading-relaxed">
                  "{quote}"
                </p>
              ))}
            </div>
          </div>
          
          <div className="bg-gradient-to-br from-blue-50 to-slate-50 rounded-2xl p-6 border border-blue-100">
            <h3 className="text-lg font-bold text-blue-700 mb-4 flex items-center">
              <Star className="h-5 w-5 mr-2" />
              Más Inspiración
            </h3>
            <div className="space-y-3">
              {loveQuotes.slice(3).map((quote, index) => (
                <p key={index} className="text-blue-600 italic text-sm leading-relaxed">
                  "{quote}"
                </p>
              ))}
            </div>
          </div>
        </div>

        {/* Messages list */}
        <div className="space-y-8">
          <h2 className="text-2xl font-bold text-gray-800 flex items-center">
            <Heart className="h-6 w-6 text-purple-500 fill-current mr-3" />
            Nuestros Mensajes de Amor
          </h2>
          
          {messages.map((message, index) => (
            <div
              key={message.id}
              className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-rose-300 hover:shadow-xl transition-all duration-300 animate-fade-in"
              className="bg-white rounded-2xl shadow-lg p-6 border-l-4 border-purple-300 hover:shadow-xl transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="flex items-start justify-between mb-4">
                <Quote className="h-8 w-8 text-purple-300 flex-shrink-0" />
                <button
                  onClick={() => addHeart(message.id)}
                  className="flex items-center space-x-2 text-purple-500 hover:text-purple-600 transition-colors group"
                >
                  <Heart 
                    className={`h-5 w-5 transition-all duration-200 group-hover:scale-110 ${
                      message.hearts > 0 ? 'fill-current' : ''
                    }`} 
                  />
                  <span className="font-medium">{message.hearts}</span>
                </button>
              </div>
              
              <p className="text-gray-700 leading-relaxed text-lg mb-4 pl-2">
                {message.text}
              </p>
              
              <div className="flex items-center justify-between text-sm text-gray-500 pl-2">
                <span>Con todo mi amor</span>
                <span>
                  {new Date(message.date).toLocaleDateString('es-ES', { 
                    year: 'numeric', 
                    month: 'long', 
                    day: 'numeric' 
                  })}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Messages;