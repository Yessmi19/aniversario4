import React, { useState } from 'react';
import { Calendar, Heart, Sparkles, Star, MapPin, Coffee, Edit3, Save, X } from 'lucide-react';

const Timeline: React.FC = () => {
  const [editingEvent, setEditingEvent] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({ title: '', description: '', date: '' });

  const [timelineEvents, setTimelineEvents] = useState([
    {
      id: 1,
      title: 'Nos Conocimos',
      description: 'El destino nos puso en el mismo camino y nuestros corazones supieron inmediatamente que algo especial estaba comenzando.',
      date: '2024-04-10',
      icon: Sparkles,
      color: 'from-purple-400 to-pink-400'
    },
    {
      id: 2,
      title: 'Primera Cita',
      description: 'Nervios, sonrisas tímidas y la certeza de que queríamos conocernos mejor. El tiempo se detuvo ese día.',
      date: '2024-04-17',
      icon: Coffee,
      color: 'from-blue-400 to-cyan-400'
    },
    {
      id: 3,
      title: 'Primer Beso',
      description: 'Bajo las estrellas, nuestros labios se encontraron por primera vez. Fue mágico, tierno y lleno de promesas.',
      date: '2024-05-01',
      icon: Heart,
      color: 'from-purple-400 to-indigo-400'
    },
    {
      id: 4,
      title: 'Nos Hicimos Novios',
      description: 'El día más hermoso. Oficialmente comenzamos esta aventura de amor que nos ha llenado de felicidad.',
      date: '2024-04-10',
      icon: Star,
      color: 'from-slate-400 to-gray-400'
    },
    {
      id: 5,
      title: 'Primer Viaje Juntos',
      description: 'Descubrimos nuevos lugares y creamos recuerdos inolvidables. Cada momento fue perfecto a tu lado.',
      date: '2024-06-05',
      icon: MapPin,
      color: 'from-cyan-400 to-blue-400'
    },
    {
      id: 6,
      title: '4 Meses de Amor',
      description: '¡Hoy celebramos 4 meses llenos de amor, risas, aventuras y sueños compartidos. ¡Por muchos más!',
      date: '2024-08-10',
      icon: Calendar,
      color: 'from-purple-400 to-blue-400',
      isToday: true
    }
  ]);

  const calculateDaysFromStart = (date: string) => {
    const startDate = new Date('2024-04-10');
    const eventDate = new Date(date);
    const diffTime = eventDate.getTime() - startDate.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays === 0 ? 'Día 0' : `Día ${diffDays}`;
  };

  const startEdit = (event: any) => {
    setEditingEvent(event.id);
    setEditForm({
      title: event.title,
      description: event.description,
      date: event.date
    });
  };

  const cancelEdit = () => {
    setEditingEvent(null);
    setEditForm({ title: '', description: '', date: '' });
  };

  const saveEdit = () => {
    setTimelineEvents(timelineEvents.map(event => 
      event.id === editingEvent 
        ? { ...event, title: editForm.title, description: editForm.description, date: editForm.date }
        : event
    ));
    setEditingEvent(null);
    setEditForm({ title: '', description: '', date: '' });
  };

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex justify-center items-center mb-6">
            <div className="relative">
              <Calendar className="h-16 w-16 text-purple-500" />
              <Heart className="h-6 w-6 text-blue-400 fill-current absolute -top-2 -right-2 animate-pulse" />
            </div>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-purple-600 via-blue-500 to-slate-600 bg-clip-text text-transparent mb-6">
            Nuestra Historia
          </h1>
          <p className="text-gray-600 text-lg max-w-3xl mx-auto leading-relaxed">
            Cada momento juntos ha sido especial. Aquí está la cronología de nuestro hermoso amor,
            desde el primer encuentro hasta este día tan especial.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Timeline line */}
          <div className="absolute left-6 md:left-1/2 md:transform md:-translate-x-px h-full w-0.5 bg-gradient-to-b from-rose-200 via-pink-300 to-red-200"></div>
          <div className="absolute left-6 md:left-1/2 md:transform md:-translate-x-px h-full w-0.5 bg-gradient-to-b from-purple-200 via-blue-300 to-slate-200"></div>

          {/* Timeline events */}
          <div className="space-y-12">
            {timelineEvents.map((event, index) => {
              const IconComponent = event.icon;
              const isEven = index % 2 === 0;

              return (
                <div
                  key={event.id}
                  className={`relative flex items-center ${
                    isEven ? 'md:flex-row' : 'md:flex-row-reverse'
                  } animate-fade-in`}
                  style={{ animationDelay: `${index * 200}ms` }}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-6 md:left-1/2 md:transform md:-translate-x-1/2 z-10">
                    <div className={`w-12 h-12 rounded-full bg-gradient-to-br ${event.color} flex items-center justify-center shadow-lg ${
                      event.isToday ? 'animate-pulse ring-4 ring-yellow-200' : ''
                    }`}>
                      <IconComponent className="h-6 w-6 text-white" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className={`w-full md:w-5/12 ml-20 md:ml-0 ${
                    isEven ? 'md:pr-16' : 'md:pl-16'
                  }`}>
                    <div className={`bg-white rounded-2xl shadow-lg p-6 border-l-4 border-gradient-to-b ${event.color} hover:shadow-xl transition-all duration-300 hover:-translate-y-1 relative group ${
                      event.isToday ? 'ring-2 ring-yellow-200 bg-gradient-to-br from-yellow-50 to-orange-50' : ''
                    }`}>
                      {/* Edit button */}
                      {!event.isToday && editingEvent !== event.id && (
                        <button
                          onClick={() => startEdit(event)}
                          className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-200 p-2 bg-gray-100 hover:bg-gray-200 rounded-full"
                        >
                          <Edit3 className="h-4 w-4 text-gray-600" />
                        </button>
                      )}

                      {event.isToday && (
                        <div className="flex items-center mb-3">
                          <Sparkles className="h-4 w-4 text-yellow-500 mr-2" />
                          <span className="text-yellow-600 font-bold text-sm">¡HOY!</span>
                        </div>
                      )}
                      
                      {editingEvent === event.id ? (
                        <div className="space-y-4">
                          <div>
                            <input
                              type="text"
                              value={editForm.title}
                              onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-300 focus:border-rose-400 font-bold text-lg"
                            />
                          </div>
                          <div>
                            <textarea
                              value={editForm.description}
                              onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                              rows={3}
                              className="w-full px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-300 focus:border-rose-400 resize-none"
                            />
                          </div>
                          <div>
                            <input
                              type="date"
                              value={editForm.date}
                              onChange={(e) => setEditForm({ ...editForm, date: e.target.value })}
                              className="px-3 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-rose-300 focus:border-rose-400"
                            />
                          </div>
                          <div className="flex space-x-2">
                            <button
                              onClick={saveEdit}
                              className="flex items-center space-x-1 px-3 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-colors"
                            >
                              <Save className="h-4 w-4" />
                              <span>Guardar</span>
                            </button>
                            <button
                              onClick={cancelEdit}
                              className="flex items-center space-x-1 px-3 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600 transition-colors"
                            >
                              <X className="h-4 w-4" />
                              <span>Cancelar</span>
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="text-xl font-bold text-gray-800">{event.title}</h3>
                            <span className="text-sm font-medium text-purple-500 bg-purple-50 px-3 py-1 rounded-full">
                              {calculateDaysFromStart(event.date)}
                            </span>
                          </div>
                          
                          <p className="text-gray-600 leading-relaxed mb-4">{event.description}</p>
                          
                          <div className="flex items-center text-sm text-gray-500">
                            <Calendar className="h-4 w-4 mr-2" />
                            {new Date(event.date).toLocaleDateString('es-ES', { 
                              year: 'numeric', 
                              month: 'long', 
                              day: 'numeric' 
                            })}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg">
            <div className="text-3xl font-bold text-purple-500 mb-2">122</div>
            <div className="text-gray-600">Días juntos</div>
          </div>
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg">
            <div className="text-3xl font-bold text-blue-500 mb-2">∞</div>
            <div className="text-gray-600">Momentos especiales</div>
          </div>
          <div className="text-center p-6 bg-white rounded-2xl shadow-lg">
            <div className="text-3xl font-bold text-slate-600 mb-2">4</div>
            <div className="text-gray-600">Meses de amor</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Timeline;