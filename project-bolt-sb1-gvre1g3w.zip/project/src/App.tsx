import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import AddMemory from './pages/AddMemory';
import Timeline from './pages/Timeline';
import Messages from './pages/Messages';
import Anniversary from './pages/Anniversary';

function App() {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home />;
      case 'add-memory':
        return <AddMemory />;
      case 'timeline':
        return <Timeline />;
      case 'messages':
        return <Messages />;
      case 'anniversary':
        return <Anniversary />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-blue-50 to-slate-100">
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main className="pt-20">
        {renderPage()}
      </main>
    </div>
  );
}

export default App;